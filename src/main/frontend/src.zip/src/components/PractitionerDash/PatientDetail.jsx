import React from 'react'

const PatientDetail = () => {
  return (
    <div>PatientDetail</div>
  )
}

export default PatientDetail