//SignUpStep2.jsx
import React, { useState, useEffect } from 'react';
import { useHistory, useLocation } from 'react-router-dom';
import './Form.css';
import { SignUpData2 } from '../../../Data/SignUpData';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
import RemoveRedEyeIcon from '@mui/icons-material/RemoveRedEye';
import SignUpStep3 from "./SignUpStep3";

const SignUpStep2 = () => {
    const history = useHistory();
    const location = useLocation();
    const [formData, setFormData] = useState({
        password: '',
        confirmPassword: ''
    });

    const goBack = () => {
        history.push('/register'); // 使用history.push()方法导航到主页
    };

    const [showPassword, setShowPassword] = useState(false);

    useEffect(() => {
        if (location.state && location.state.formData) {
            setFormData(location.state.formData);
        }
    }, [location]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    const handleToggleShowPassword = () => {
        setShowPassword(!showPassword);
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log("Form Data:", formData); // 打印表单数据以进行调试
        if (!formData.password.trim() || !formData.confirmPassword.trim()) {
            alert("All field cannot be empty.");
            return;
        }
        if (formData.password !== formData.confirmPassword) {
            alert("Passwords do not match!");
            return;
        }
        sessionStorage.setItem('signUpDataStep2', JSON.stringify(formData)); // Save form data to sessionStorage
        history.push('/register-3', { formData }); // Navigate to next step
    };

    return (
        <div style={{backgroundColor: "#eaf0f7", display: "flex", height: "100vh"}}>
            <div className="bg-register">
                <h1>Sign Up</h1>
                <form onSubmit={handleSubmit} className="form-container mform1">
                    {SignUpData2.map((field, index) => (
                        <div className="input-group" key={index}>
                            <label htmlFor={field.name}>{field.label}</label>
                            <input
                                type={showPassword ? "text" : "password"}
                                id={field.name}
                                name={field.name}
                                placeholder={field.placeholder}
                                onChange={handleChange}
                                value={formData[field.name]}
                                className="text-input"
                            />
                            <span onClick={handleToggleShowPassword}>
                            {showPassword ? <VisibilityOffIcon/> : <RemoveRedEyeIcon/>}
                        </span>
                        </div>
                    ))}
                    <button type="submit" className='submit-btn'> Next Step</button>
                    <button onClick={goBack} className='submit-btn'> Previous Step</button>
                </form>
            </div>

        </div>

    );
}

export default SignUpStep2;