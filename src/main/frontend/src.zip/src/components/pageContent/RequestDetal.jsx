import React from 'react'
import '../PractitionerDash/Practitioner.css'
import Sidebar from '../PractitionerDash/Sidebar/Sidebar';
import MainDash from '../PractitionerDash/MainDash/MainDash';


export const PractitionerDash = () => {
  return (
    <div className='background'>
    <div className='p-container'>
        
    </div>
    </div>
  );
}

export default PractitionerDash;