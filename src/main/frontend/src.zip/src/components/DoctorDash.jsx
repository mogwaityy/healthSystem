import React from 'react'
import AppointmentTable from './PractitionerDash/Table/AppointmentTable'

const DoctorDash = () => {
  return (
    <div><AppointmentTable/></div>
  )
}

export default DoctorDash