
import { emitter } from "@/api/m/index"
// 自定义Hook：用于获取数据
export default function useMit() {
  return { emitter };
}