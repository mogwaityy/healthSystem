export const cardsData = [
    {
      title: "New Requests",
      value: "20"
    },
    {
      title: "On Processing",
      value: "21"
    }
  ];